# Comic Book

## Introduction

- This is Quiz1
- Name: Yiziyin Yao
- NUID: 001341398

## Detail:

images folder: store source image and generated image

Comic.ipynb: Jupyter python code document

dialog.csv: dialog source document

Fantastic_Comics.jpg: cover

avengers.pdf: comic book 