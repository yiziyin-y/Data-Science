# Statistical Language Translator

## Introduction

- This is Assignemnt6
- Name: Yiziyin Yao
- NUID: 001341398
- Teammate:  Sichen Zhao , Jingyu Wang

## Detail:

1.Tokenizer.ipynb: sperate whole article into segmented words

2.pos-tagging-hmm-start-Homework.ipynb: model and code file, contain all comments and codes

3.newfile.txt: store divided sentence that segment from words

4.tags.txt: English words that occur as tag

5.jane.txt: original article