# Data Science for Sports

## Introduction

- This is Assignment4
- Name: Yiziyin Yao
- NUID: 001341398

## Detail:

Sport.ipynb : all of codes and comment

