# Modeling Rainfall with the 𝛾 distribution

## Introduction

- This is Assignemnt7
- Name: Yiziyin Yao
- NUID: 001341398

## Detail:

1.bayesian-lab-rainfall-hw20.ipynb: sperate whole article into segmented words

2.compare.docx: compare professor's solution and yang's solution