# Distribution Analyze

## Introduction

- This is Assignment5
- Name: Yiziyin Yao
- NUID: 001341398

## Detail:

Homework5 Distribution.ipynb : all of codes and comment

data2: source data folder