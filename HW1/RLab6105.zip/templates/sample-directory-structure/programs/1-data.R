source("header.R")

dfzz <- read.csv("../data/final.csv")


dfz <- dfzz
saveRDS(dfz,"dfz.rds")



